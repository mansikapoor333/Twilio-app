# Python_whatsapp_automated_msgs
A python code for sending automated messages over whatsapp configured over particular timings, using Twilio API key and deployed to Heroku
